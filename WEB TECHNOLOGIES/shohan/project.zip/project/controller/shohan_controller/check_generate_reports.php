<?php
if (isset($_POST['download_report'])) {
    
    echo "<h3 style='font-family: Arial, sans-serif; color: green; text-align: center;'>Will Updated</h3>";
}
?>