<?php 
session_start();
if($_SESSION['status'] == true){

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="signin.css">
    <title>User Menu</title>
</head>
<body>
    <div class="main_container">
        <div class="container">
            <div class="header">
                <div class="logo_container">
                    <img src="../../SVG/adventure.svg" alt="adventure logo" height="20px">
                </div>
            </div>
            <div class="left">
                <h1 align="center">Welcome to User Menu</h1>
            </div>
            <div class="right">
                <a href="">Dashboard</a> <br>
                <a href="">Create AD</a> <br>
                <a href="">Wishlist</a> <br>
                <a href="">Ad categories</a> <br>
                <a href="">Search ADs/a> <br>
                    <a href="">Feedback</a> <br>
                    <a href="">View Profile </a> <br>
                    <a href="">Edit Profile Photo</a> <br>
                    <a href="">Change Password</a><br>
                    <a href="../../controller/logout.php">Logout</a>
            </div>
        </div>
        <div class="footer">footer</div>
    </div>
    </div>
</body>
</html>

<?php }
else{
    header("locatoin:../../signin/signin.html");
} ?>